Place ffmpeg.exe in this folder.

Recommended:
- Download a Windows static build of FFmpeg from the official site.
- Ensure the executable name is exactly: ffmpeg.exe

The app will look for:
AnimeQuoteWall.GUI/Resources/ffmpeg/ffmpeg.exe

You can also override this path in settings via AppConfiguration.FfmpegPath.

